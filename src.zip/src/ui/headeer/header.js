import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Addtocart from "../addtoCart/addtoCart";
import Logo from '../logo/logo';
import './header.css';

class Header extends Component {
    render() {
        return (
            <React.Fragment>
                <header className="clearfix">
                <Logo/>
                <div className="main-menu-wrapper">
                <ul className="main-menu-wrapper"> 
                    <li>
                        <Link to="/">Home</Link>
                    </li>
                    <li>
                        <Link to="/about">About</Link>
                    </li>
                    <li>
                        <Link to="/topics">Topics</Link>
                    </li>
                </ul>
                </div>
                <Addtocart/>
            </header>
            </React.Fragment>

        );
    }
}
export default Header;