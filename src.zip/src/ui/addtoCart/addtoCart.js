import React, { Component } from "react";

class Addtocart extends Component {
    render() {
        return (
            <div className="addtocart-wrapper">
                <span className="addtocart-icon"><img src="../images/add-shopping-cart.png" /></span>
                {this.props.itemLength > '0' ? (
                    <span className="itemCount">{this.props.itemLength}</span>
                ) : ''}
            </div>
        );
    }
}
export default Addtocart;