import React, { Component } from 'react';
import Slider from 'react-slick';
import {Background} from '../common'
import './banner.css';

class Banner extends Component {
    constructor(props) {
        super(props);
    }


    render() {
        var settings = {
            dots: false,
            infinite: true,
            speed: 1500,
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay:true,
            arrows: false
        };
        return (
            <React.Fragment>
                <div className="banner-wrapper">
                    <Slider {...settings} className="clearfix">
                        <div className="clearfix">
                            <span style={Background('../images/banners/banner_1.jpg')} />
                            <img src="../images/banners/banner_1.jpg" />
                        </div>
                        <div className="clearfix">
                            <span style={Background('../images/banners/banner_2.jpg')} />
                            <img src="../images/banners/banner_2.jpg" />
                        </div>
                        <div className="clearfix">
                            <span style={Background('../images/banners/banner_3.jpg')} />
                            <img src="../images/banners/banner_3.jpg" />
                        </div>
                    </Slider>
                </div>
            </React.Fragment>
        )
    };
}

export default Banner;