import React from 'react';

export const Background = (image) => {
    return {
        backgroundImage: `url(${image})`,
    }
}

export const test=(te)=>{
    return{
        te
    }
}
