import React, { Component } from 'react';
import { Background, test } from '../common'
import Addtocart from "../addtoCart/addtoCart";
import './vehicles.css'


class Vehicals extends Component {
    constructor(props) {
        super(props);
        this.state = {
            itemCount: 0,
            vehicalData: [
                { id: 'item01', name: 'CAR AIR Item 01', discription: 'Give you the fresher air and make the health condition. Learn More', image: '../images/car/item1.jpg' },
                { id: 'item02', name: 'CAR AIR Item 02', discription: 'Give you the fresher air and make the health condition. Learn More', image: '../images/car/item2.jpg' },
                { id: 'item03', name: 'CAR AIR Item 03', discription: 'Give you the fresher air and make the health condition. Learn More', image: '../images/car/item3.jpg' },
                { id: 'item04', name: 'CAR AIR Item 04', discription: 'Give you the fresher air and make the health condition. Learn More', image: '../images/car/item4.jpg' },
                { id: 'item05', name: 'CAR AIR Item 05', discription: 'Give you the fresher air and make the health condition. Learn More', image: '../images/car/item5.jpg' },
                { id: 'item06', name: 'CAR AIR Item 06', discription: 'Give you the fresher air and make the health condition. Learn More', image: '../images/car/item6.jpg' },
                { id: 'item07', name: 'CAR AIR Item 07', discription: 'Give you the fresher air and make the health condition. Learn More', image: '../images/car/item2.jpg' },
                { id: 'item08', name: 'CAR AIR Item 08', discription: 'Give you the fresher air and make the health condition. Learn More', image: '../images/car/item4.jpg' },
                { id: 'item09', name: 'CAR AIR Item 09', discription: 'Give you the fresher air and make the health condition. Learn More', image: '../images/car/item6.jpg' }
            ],
            itemAddedArray: [],
            deleteItemArray: []

        };
        global.itemlengthInt = 0;
        this.addtoCartItem = this.addtoCartItem.bind(this);
    }

    addtoCartItem = (e, data, name) => {
        e.preventDefault();
        global.itemlengthInt = global.itemlengthInt + 1;
        this.setState({
            itemCount: global.itemlengthInt
        })

        this.state.itemAddedArray.push({ 'id': data, 'name': name });
        console.log(this.state.itemAddedArray);
        e.target.parentNode.className = 'x-list-item clearfix four columns news-item highlight';
    }

    removeCartItem = (e, data, name) => {
        e.preventDefault();
        global.itemlengthInt = global.itemlengthInt - 1;
        this.setState({
            itemCount: global.itemlengthInt
        })
        this.state.deleteItemArray.push({ 'id': data, 'name': name });
        var result1 = this.state.itemAddedArray;
        var result2 = this.state.deleteItemArray;
        var props = ['id', 'name'];
        var result = result1.filter(function (o1) {
            return !result2.some(function (o2) {
                return o1.id === o2.id;
            });
        }).map(function (o) {
            return props.reduce(function (newo, name) {
                newo[name] = o[name];
                return newo;
            }, {});
        });
        this.state.itemAddedArray = result;
        console.log(this.state.itemAddedArray)
        e.target.parentNode.className = 'x-list-item clearfix four columns news-item';
    }

    render() {
        return (
            <div className="clearfix x-list-item-wrapper">
                <Addtocart itemLength={this.state.itemCount} />
                {this.state.vehicalData.map((itemData) =>
                    <div key={itemData.id} className="x-list-item clearfix four columns news-item">
                        <span className="add-to-cart" onClick={(e) => {
                            this.addtoCartItem(e, itemData.id, itemData.name)
                        }}>&#43;</span>
                        <span className="add-to-cart remove-to-cart" onClick={(e) => {
                            this.removeCartItem(e, itemData.id, itemData.name)
                        }}>-</span>
                        <input type="text" className="item-count" />

                        <div className="image-wrapper" style={Background(itemData.image)}>
                            <img className="default vmb2 full-width" src={itemData.image} alt="" />
                        </div>
                        <div className="content-wrapper">
                            <div className="content-inner-wrapper">
                                <h3>{itemData.name}</h3>
                                <p>{itemData.discription}</p>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        )
    };
};


export default Vehicals;