import React,{Component} from 'react';

class Logo extends Component{
    render(){
        return(
            <div className="logo-wrapper"><img src="../images/logo.svg"/></div>
        )
    };
}

export default Logo;
