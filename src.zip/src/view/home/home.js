import React, { Component } from 'react';
import Banner from '../../ui/banner/Banner';
import Vehicals from '../../ui/vehicles/vehicles';

class Home extends Component {
    render() {
        return (
            <React.Fragment>
                <Banner />
                <div className="main-container">
                    <div className="main">
                        <Vehicals />
                    </div>
                </div>
            </React.Fragment>
        )
    };
}

export default Home;